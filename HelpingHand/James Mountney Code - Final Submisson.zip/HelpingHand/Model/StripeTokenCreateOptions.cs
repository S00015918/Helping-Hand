﻿namespace HelpingHand
{
    internal class StripeTokenCreateOptions
    {
        public StripeTokenCreateOptions()
        {
        }

        public StripeCreditCardOptions Card { get; set; }
    }
}